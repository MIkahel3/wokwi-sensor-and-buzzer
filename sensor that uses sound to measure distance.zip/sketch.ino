const int trigPin=10;
const int echoPin=11;
void setup() {
  // put your setup code here, to run once:
pinMode(trigPin, OUTPUT);
pinMode(echoPin, INPUT);
Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
digitalWrite(trigPin, LOW);
delayMicroseconds(2);
digitalWrite(trigPin, HIGH);
delayMicroseconds(10);
digitalWrite(trigPin, LOW);
long durata=pulseIn(echoPin, HIGH);
float distance=durata*0.034/2;
int frecventa=map(distance, 2, 400, 2000, 100);
tone(8, frecventa);
Serial.print(distance);
Serial.println(" cm");
delay(300);
}